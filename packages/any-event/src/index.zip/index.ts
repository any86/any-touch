type Covert2Array<T> = T extends unknown[] ? T : [T];
export interface Listener<Payloads> {
    (...payloads: Covert2Array<Payloads>): void;
    beforeEmit?: (...payloads: Covert2Array<Payloads>) => boolean;
}

export interface ListenersMap<Payloads> {
    [type: string | symbol]: Listener<Payloads>[];
}

// 拦截器
export interface Interceptor {
    (context: ThisType<this>, next: () => void): void
}

// Payloads 后面会自动转成数组
export default class <Payloads> {
    // 事件仓库
    private __map: ListenersMap<Payloads> = {};
    // 拦截器
    private __interceptor?: Interceptor;

    /**
     * 注册拦截器
     * @param interceptor 拦截器
     */
    beforeEach(interceptor: Interceptor) {
        this.__interceptor = interceptor;
    }

    /**
     * 绑定事件
     * @param typeOrTypes 事件名
     * @param listener 回调函数
     * @param beforeEmit 触发拦截器, 一般用在对on的二次封装
     */
    on(typeOrTypes: string | string[], listener: Listener<Payloads>, beforeEmit?: (...payload: Covert2Array<Payloads>) => boolean): this {
        const types = Array.isArray(typeOrTypes) ? typeOrTypes : [typeOrTypes];

        for (const type of types) {
            if (void 0 === this.__map[type]) {
                this.__map[type] = [];
            }
            listener.beforeEmit = beforeEmit;
            this.__map[type].push(listener);
        }
        return this;
    }

    /**
     * 按照监听器注册的顺序，同步地调用每个注册到名为 eventName 的事件的监听器，并传入提供的参数。
     * @param type 事件名
     * @param payload 载荷数据
     * @returns  如果事件有监听器，则返回 true，否则返回 false。
     */
    emit<T extends Covert2Array<Payloads>>(type: string, ...payloads: T): void {
        if (void 0 !== this.__interceptor) {
            this.__interceptor(this, () => {
                emit(this.__map, type, ...payloads);
            });
        } else {
            emit(this.__map, type, ...payloads);
        }
    }

    /**
     * 解除绑定,
     * 如果不指定listener,
     * 那么解除所有eventName对应回调
     * @param eventName 事件名
     * @param listener 回调函数
     */
    off(eventName: string, listener?: Listener<Payloads>): void {
        const listeners = this.__map[eventName];
        // 事件存在
        if (void 0 !== listeners) {
            // 清空事件名对应的所有回调
            if (void 0 === listener) {
                delete this.__map[eventName];
            }
            // 清空指定回调
            else {
                const index = listeners.findIndex((fn: Listener<Payloads>) => fn === listener);
                listeners.splice(index, 1);
            }
        }
    }

    /**
     * 销毁实例
     */
    destroy() {
        this.__map = {};
    }
}

function emit<T>(map: ListenersMap<T>, eventName: string, ...payloads: Covert2Array<T>) {
    const listeners = map[eventName];
    if (void 0 !== listeners && 0 < listeners.length) {
        for (const listener of listeners) {
            if (void 0 === listener.beforeEmit) {
                listener(...payloads);
            } else if (void 0 !== payloads && listener.beforeEmit(...payloads)) {
                listener(...payloads);
            }
        }
    }
}